d3.csv("oecd/barData.csv", function(error, data){
	
	// 바 그래프의 폭과 그래프 간의 간격을 설정
	var barWidth = 25
	var barGap = 5

	// svg 크기 구하기
	// var svgEle = document.getElementById("myGraph")
	// var svgWidth = window.getComputedStyle(svgEle, null).getPropertyValue('width')
	// var svgHeight = window.getComputedStyle(svgEle, null).getPropertyValue('height')
	// var svgWidth = parseFloat(svgWidth)
	// var svgHeight = parseFloat(svgHeight)

	var svgWidth = 0
	var svgHeight = 0
	
	// var svgHeight = 240;

	// 바 그래프 요소
	var barElements

	// svgWidth를 데이터의 갯수로 나누면 (barWidtw+barGap) 이 값을 얻을 수 있고 여기서 적절하게 분배하는 것이 필요	
	// 비율로 할 수 있는 방법은 없을까?


 
	

	// 데이터 로딩
	var dataSet = []  // empty array to store data
	var dataLabel = []
	var scaleExpandMultiplier = 1
	var axisScaleMultiplier = 1

	for(var i = 0; i < data.length; i++) {
		dataSet.push(data[i].value * scaleExpandMultiplier)
		dataLabel.push(data[i].country)
		svgWidth += barWidth + barGap		
		if(svgHeight < parseInt(data[i].value * axisScaleMultiplier)){
			svgHeight = data[i].value * axisScaleMultiplier
			}
		}
	

	var yScale = d3.scale.linear()
		.domain([0, d3.max(dataSet, function(d){ return d} )])
		.range([0, 400]);
	
	var offsetX = 30;
	var offsetY = 30;
	
	svgWidth += 2 * offsetX
	tempSvgHeight = parseInt(svgHeight)
	svgHeight = tempSvgHeight + 6
	// console.log(svgWidth);
	// console.log(svgHeight);
	// console.log(tempSvgHeight);
	// console.log(tempSvgHeight/axisScaleMultiplier*scaleExpandMultiplier)


	console.log(yScale(svgHeight))
	// 요소 추가
	barElements = d3.select("#myGraph")
		.attr('width', svgWidth)
		.attr('height', yScale(svgHeight))
		.append('g')
		.attr('transform', 'translate(' + offsetX + ', ' + offsetY+')' )
		.selectAll("rect")
		.data(dataSet)
	
	// 레이블 추가
	// barElements.enter()
	//   .append("text")
	//   .attr("class", "barNum")
	//   .attr("x", function(d, i){
	//   	return i * (barWidth + barGap) + barWidth/2})
	//   .attr("y", function(d, i){
	//   	return yScale(tempSvgHeight) - yScale(d)})
	//   .text(function(d, i){
	//   		n = d;
	//   	return n.toFixed(2)});
	 
	// 아래서 위로 그리기
	barElements.enter() 
	  .append("rect")
		.attr("class", "bar")
		.attr('height', 0) // 초기 높이 설정을 해줘야 함. 안그러면 이상하게 시작
		.attr("width", barWidth)
		.attr("x", function(d, i) { return i * ( barWidth + barGap ) })
		// .attr("y", function(d, i){ return yScale(tempSvgHeight) })
		// .on('mouseover', function(){
						
		// }) 
		
		
		// .transition() // transition 전에 interaction 코드를 추가해야 함.
		// .delay(function(d, i){
		// 	return i * 500
		// })
		// .duration(3000)
		.attr('y', function(d, i){
			return yScale(tempSvgHeight) - yScale(d)
		})
		.attr("height", function(d, i) { return yScale(d)})
		.on('mouseover', function(d){
			d3.select(this)
			  .style('fill', 'orange');	
			var xPosition = parseFloat(d3.select(this).attr("x")) + barWidth/2 ;
			var yPosition = parseFloat(d3.select(this).attr("y")) - yScale(d);

			barElements.append('text')
			   .attr('id', 'tooltip')
			   .attr("x", xPosition)
			   .attr("y", yPosition)
			   .attr("text-anchor", "middle")
			   .attr("font-family", "sans-serif")
			   .attr("font-size", "11px")
			   .attr("font-weight", "bold")
			   .attr("fill", "black")
			   .text(d);
		})
		.on('mouseout', function(){
			d3.select(this)
				.transition()
				.duration(500)
				.style('fill', '#ccc')
			d3.select("#tooltip").remove();
		})
		;

	//x축 이름 추가
	// barElements.enter()
	//    .append('text')
	//    .attr('class', 'barcountry')
	//    .attr('x', function(d, i){
	//    	return i * (barWidth + barGap) + barWidth/2
	//    })
	//    .attr('y', svgHeight + offsetY - 5)	  
	//    .text(function(d, i){ return dataLabel[i]})


	var yScaleForAxis = d3.scale.linear()
		.domain([0, d3.max(dataSet, function(d){ return d} )])
		.range([400, 0]);


	// y축 그리기
	d3.select('#myGraph').append('g')
		.attr('class', 'axis')
		.attr('transform', 'translate(' + (offsetX-5) + ', ' + (offsetY-10)+ ')')
		.call(
			d3.svg.axis()
			.scale(yScaleForAxis)
			.orient('left')
			)

	// x축 그리기 
	d3.select('#myGraph')
		.append('rect')
		.attr('class', 'axis_x')
		.attr('width', svgWidth)
		.attr('height', 1)
		.attr('transform', 'translate(' + 
			(offsetX-5) + ', ' + (yScale(tempSvgHeight) + offsetY)+')')	
		// .attr('x', offsetX)
		// .attr('y', svgHeight-offsetY) 




})