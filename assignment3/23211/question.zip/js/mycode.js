d3.csv("data/mydata.csv", function(error, data){
	
	// 바 그래프의 폭과 그래프 간의 간격을 설정
	var barWidth = 25
	var barGap = 5
	
	// 바 그래프 요소
	var barElements

	// 데이터 로딩
	var dataSet = []  // empty array to store data
	for(var i = 0; i < data.length; i++) {
		dataSet.push(data[i].item1)
	}
	
	// 요소 추가
	barElements = d3.select("#myGraph")
		.selectAll("rect")
		.data(dataSet)
	
	// 데이터 추가
	barElements.enter()
	  .append("rect")
		.attr("class", "bar")
		.attr("x", function(d, i) { return i * ( barWidth + barGap ) })
		.attr("y", 0)
		.attr("width", barWidth)										
		.attr("height", function(d, i) { return d })
	
})